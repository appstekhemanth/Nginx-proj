import React,{ Component } from 'react';

 class Settings extends Component {
     render(){
         return(
            <div style={{ display: 'flex', justifyContent: 'center' }} className="container">
            <h3 style={{ display: 'flex', alignItems: 'center' }} className="pagename">No Data Available</h3>
        </div>
         );
     }
 }

 export default Settings;