import React,{ Component } from 'react';
//import '../../assets/css/style.css';

 class EventHistory extends Component {
     render(){
         return(
            <div style={{ display: 'flex', justifyContent: 'center',height:'10px' }} className="container">
            <h3  className="pagename">No Data Available</h3>
        </div>
         );
     }
 }

 export default EventHistory;