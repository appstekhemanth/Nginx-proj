import React, {Component} from 'react';

class Footer extends Component {
    render(){
      return (
          <div className="footer-sec">
            <p>Version 1.23</p>
          </div>
              )
      }
}

export default Footer;