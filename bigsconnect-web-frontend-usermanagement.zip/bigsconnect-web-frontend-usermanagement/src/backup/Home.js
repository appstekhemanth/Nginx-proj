import React,{ Component } from 'react';
//import UserManagement from './UserManagement';
//import UserManagementNav from './UserManagementNav';
 class Home extends Component {
     render(){
         return(
             <div>
                 <h1 className="pagename">
                     Bigs Dashboard
                 </h1>
                     {/* <UserManagementNav/> */}
                 
             </div>
         );
     }
 }

 export default Home;